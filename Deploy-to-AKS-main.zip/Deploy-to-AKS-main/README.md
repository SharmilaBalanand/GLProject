# Deploy-to-AKS

Repository for showcasing the deployment from Azure DevOps Pipelines to AKS.

This repo has been used during the [CoderDave](https://youtube.com/CoderDave) live streaming:

[![Deploy to AKS](https://img.youtube.com/vi/4Oa5HneTuKs/0.jpg)](https://youtu.be/4Oa5HneTuKs)
